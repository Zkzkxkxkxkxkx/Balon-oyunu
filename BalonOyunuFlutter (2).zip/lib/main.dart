import 'package:flutter/material.dart';
import 'dart:math';

void main() => runApp(BalonOyunu());

class BalonOyunu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Balon Oyunu',
      home: BalonAnaSayfa(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class BalonAnaSayfa extends StatefulWidget {
  @override
  _BalonAnaSayfaState createState() => _BalonAnaSayfaState();
}

class _BalonAnaSayfaState extends State<BalonAnaSayfa> {
  int skor = 0;
  double balonX = 100;
  double balonY = 400;

  void _hareketEttir() {
    setState(() {
      final random = Random();
      balonX = random.nextDouble() * 300;
      balonY = random.nextDouble() * 500;
      skor++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue[100],
      appBar: AppBar(title: Text("Balon Patlat!")),
      body: Stack(
        children: [
          Positioned(
            left: balonX,
            top: balonY,
            child: GestureDetector(
              onTap: _hareketEttir,
              child: Image.network(
                'https://i.imgur.com/3yY0TDV.png',
                width: 80,
              ),
            ),
          ),
          Positioned(
            top: 20,
            left: 20,
            child: Text("Skor: \$skor",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          )
        ],
      ),
    );
  }
}
